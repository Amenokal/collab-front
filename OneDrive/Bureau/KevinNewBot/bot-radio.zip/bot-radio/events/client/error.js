module.exports = {
	name: 'error',
	category: 'client',
	enabled: true,
	once: true,
	run: async (error) => {
		console.log(`» ERROR - ${error}`);
	},
};