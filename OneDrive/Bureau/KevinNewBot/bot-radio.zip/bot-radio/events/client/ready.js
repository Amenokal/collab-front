const { ActivityType } = require("discord.js");
const { generateDependencyReport } = require("@discordjs/voice");

const statuses = require("../../assets/json/status.json");

module.exports = {
  name: "ready",
  category: "client",
  enabled: true,
  once: true,
  run: async (client) => {
    // console.log(client);
    setInterval(async () => {
      const status = statuses[Math.floor(Math.random() * statuses.length)];

      client.user.setActivity(`${status}`, { type: ActivityType.Listening });
    }, 5000);

    console.log(generateDependencyReport());

    console.log(
      `» Bot ${client.name} is now online!\n [${client.guilds.cache.reduce(
        (a, g) => a + g.memberCount,
        0
      )}] Users | [${client.channels.cache.size}] Channels | [${
        client.guilds.cache.size
      }] Servers`
    );
  },
};
