module.exports = {
	name: 'reconnecting',
	category: 'client',
	enabled: true,
	once: true,
	run: async () => {
		console.log('» Reconnecting Client to Discord...');
	},
};