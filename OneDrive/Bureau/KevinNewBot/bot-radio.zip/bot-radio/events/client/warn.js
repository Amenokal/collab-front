module.exports = {
	name: 'warn',
	category: 'client',
	enabled: true,
	once: true,
	run: async (client) => {
		console.log(`» WARN - ${client.warn}`);
	},
};