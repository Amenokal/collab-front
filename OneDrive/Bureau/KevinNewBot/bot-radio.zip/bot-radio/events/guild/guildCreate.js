const db = require('quick.db');

module.exports = {
	name: 'guildCreate',
	category: 'guild',
	enabled: true,
	once: false,
	run: async (guild) => {
		const client = guild.client;

		const locale = await db.fetch(`locale_${guild.id}`) || client.config.defaultLocale;
		if (!locale) {
			await db.set(`locale_${guild.id}`, 'en');
		}

		console.log(`» ${guild.name} has been created.`);
	},
};