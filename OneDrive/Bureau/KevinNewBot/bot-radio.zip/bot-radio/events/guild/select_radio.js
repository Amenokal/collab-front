const {ChannelType, EmbedBuilder,ActionRowBuilder,ComponentType,StringSelectMenuBuilder } = require("discord.js");
const db = require("quick.db");
const { stripIndents } = require("common-tags");
const { joinVoiceChannel, createAudioResource, createAudioPlayer,getVoiceConnection} = require("@discordjs/voice");

module.exports = {
  name: "interactionCreate",
  category: "client",
  enabled: true,
  once: false,
  run: async (interaction) => {
try {

    if (!interaction.isStringSelectMenu()) return;
    const client = interaction.guild.client;
    const findLocale = await db.fetch(`locale_${interaction.guild.id}`);
    if (!findLocale) await db.set(`locale_${interaction.guild.id}`, "en");
	const commands = await client.application.commands.fetch();
	let inviteCMD = commands.filter((command) =>!command.name.startsWith("radio-") &&!command.name.startsWith("radioinfo-") &&!command.name.startsWith("botinfo") &&!command.name.startsWith("help") &&!command.name.startsWith("support") &&!command.name.startsWith("ping") &&!command.name.startsWith("radiolist") &&!command.name.startsWith("vote") &&!command.name.startsWith("set-language") &&!command.name.startsWith("about") &&!command.name.startsWith("legal") &&!command.name.startsWith("donate") &!command.name.startsWith("acknowledgements"));
	let supportCMD = commands.filter((command) =>!command.name.startsWith("radio-") &&!command.name.startsWith("radioinfo-") &&!command.name.startsWith("botinfo") &&!command.name.startsWith("help") &&!command.name.startsWith("invite") &&!command.name.startsWith("ping") &&!command.name.startsWith("radiolist") &&!command.name.startsWith("vote") &&!command.name.startsWith("set-language") &&!command.name.startsWith("about") &&!command.name.startsWith("legal") &&!command.name.startsWith("donate") &&!command.name.startsWith("acknowledgements"));

	const locale = await client.util.getServerLocale(interaction, findLocale);
    if (interaction.values[0] === "first_select_radio") {
      {
        await interaction.deferReply();

        const isVoc = interaction.guild.channels.cache.find(
          (channel) =>
            channel.type == ChannelType.GuildVoice &&
            !channel.members.has(interaction.user.id) &&
            channel.members.has(interaction.user.id)
        );
		const alreadyVCEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_already}`);
		if (isVoc) return interaction.editReply({ embeds: [alreadyVCEmbed] });

        const vcEmbed = client.util.CattoEmbed(client, client.user, `ml`);
        if (!interaction.member.voice.channel) return interaction.editReply({ embeds: [vcEmbed] });

        const selectRadioRow = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId("select")
            .setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
            .addOptions([
              {
                label: "Jacaranda FM",
                description: `${locale.radio_sm_description} Jacaranda FM.`,
                value: "first",
                emoji: "<:jacarandafm:1039696778557136906>",
              },
              {
                label: "Hot 102.7 FM",
                description: `${locale.radio_sm_description} Hot 102.7 FM.`,
                value: "second",
                emoji: "<:Hot1027FM:1039698928989384756>",
              },
              {
                label: "Magic 828",
                description: `${locale.radio_sm_description} Magic 828.`,
                value: "third",
                emoji: "<:Magic828:1039703846064242828>",
              },
            ])
        );

        const welcomeEmbed = new EmbedBuilder()
          .setColor(client.color.white)
          .setDescription(
            stripIndents`
				${client.emoji.Beta} ${locale.radio_w_l1}


				${client.emoji.Broadcast} ${locale.radio_w_l3}

				${client.emoji.Config} ${locale.radio_w_l4} : ${inviteCMD
              .map((c) => `</${c.name}:${c.id}>`)
              .join(" ")}

				${client.emoji.Sciences} ${locale.radio_w_l5} **${
              selectRadioRow.components[0].options.length
            }** Africa ${locale.radio_w_l6}
				
				${client.emoji.Star} ${locale.radio_w_l7} : ${supportCMD
              .map((c) => `</${c.name}:${c.id}>`)
              .join(" ")}
				`
          )
          .setThumbnail(interaction.user.displayAvatarURL({ size: 2048 }))
          .setFooter({
            text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
            iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
          });

        await interaction.editReply({
          embeds: [welcomeEmbed],
          components: [selectRadioRow],
        });

        const collector =
          await interaction.channel.createMessageComponentCollector({
            componentType: ComponentType.SelectMenu,
            time: 3600000,
            max: 999999,
          });

        collector.on("collect", async (c) => {
          const links = {
            first: "https://edge.iono.fm/xice/jacarandafm_live_medium.aac",
            second: "https://edge.iono.fm/xice/57_high.aac",
            third: "http://cast.fabrik.fm:8106/",
          };

          const thisLive = links[c.values[0]];

          const connection = joinVoiceChannel({
            channelId: interaction.member.voice.channel.id,
            guildId: interaction.guild.id,
            adapterCreator: interaction.guild.voiceAdapterCreator,
          });

          const live = createAudioResource(thisLive, {
            inlineVolume: true,
          });
          live.volume.setVolume(0.2);

          const player = createAudioPlayer();
          connection.subscribe(player);

          player.play(live);
		  collector.stop()

          interaction.followUp({
            content: `${client.emoji.Broadcast} ${locale.radio_launch} ${interaction.member.voice.channel}`,
          });

          const int = setInterval(() => {
            if (
              interaction?.member?.voice?.channel?.members?.size ===
              (0 || undefined)
            ) {
              clearInterval(int);
              getVoiceConnection(interaction.guildId).disconnect();
            }
          }, 5000);
        });
      }
    }
    if (interaction.values[0] === "second_select_radio") {
      await interaction.deferReply();

      const isVoc = interaction.guild.channels.cache.find(
        (channel) =>
          channel.type == ChannelType.GuildVoice &&
          !channel.members.has(interaction.user.id) &&
          channel.members.has(client.user.id)
      );

      const vcEmbed = client.util.CattoEmbed(
        client,
        interaction.user,
        `${client.emoji.Warn} ${locale.radio_notinvc}`
      );
      if (!interaction.member.voice.channel)
        return interaction.editReply({ embeds: [vcEmbed] });

      const alreadyVCEmbed = client.util.CattoEmbed(
        client,
        interaction.user,
        `${client.emoji.Warn} ${locale.radio_already}`
      );
      if (isVoc) return interaction.editReply({ embeds: [alreadyVCEmbed] });

      const selectRadioRow = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("select")
          .setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
          .addOptions([
            {
              label: "Listen.Moe JPop",
              description: `${locale.radio_sm_description} Listen.Moe JPop.`,
              value: "first",
              emoji: "<:radio_listenmoe:980789747117084693>",
            },
            {
              label: "Listen.moe Kpop",
              description: `${locale.radio_sm_description} Listen.moe Kpop.`,
              value: "second",
              emoji: "<:radio_listenmoe:980789747117084693>",
            },
            {
              label: "Kishiwada Radio",
              description: `${locale.radio_sm_description} Kishiwada Radio.`,
              value: "third",
              emoji: "<:kishiwada:1020828085492404244>",
            },
          ])
      );

      const welcomeEmbed = new EmbedBuilder()
        .setColor(client.color.white)
        .setDescription(
          stripIndents`
			${client.emoji.Beta} ${locale.radio_w_l1}

			${client.emoji.Tools} ${locale.radio_w_l2.replace("{{Radio}}", "Asia")}

			${client.emoji.Broadcast} ${locale.radio_w_l3}

			${client.emoji.Config} ${locale.radio_w_l4} : ${inviteCMD
            .map((c) => `</${c.name}:${c.id}>`)
            .join(" ")}

			${client.emoji.Sciences} ${locale.radio_w_l5} **${
            selectRadioRow.components[0].options.length
          }** Asia ${locale.radio_w_l6}
			
			${client.emoji.Star} ${locale.radio_w_l7} : ${supportCMD
            .map((c) => `</${c.name}:${c.id}>`)
            .join(" ")}
			`
        )
        .setThumbnail(interaction.user.displayAvatarURL({ size: 2048 }))
        .setFooter({
          text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
          iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
        });

      await interaction.editReply({
        embeds: [welcomeEmbed],
        components: [selectRadioRow],
      });

      const collector =
        await interaction.channel.createMessageComponentCollector({
          componentType: ComponentType.SelectMenu,
          time: 3600000,
          max: 999999,
        });

      collector.on("collect", async (c) => {
        const links = {
          first: "https://listen.moe/stream",
          second: "https://listen.moe/kpop/stream",
          third: "http://61.89.201.27:8000/radikishi.mp3",
        };

        const thisLive = links[c.values[0]];

        const connection = joinVoiceChannel({
          channelId: interaction.member.voice.channel.id,
          guildId: interaction.guild.id,
          adapterCreator: interaction.guild.voiceAdapterCreator,
        });

        const live = createAudioResource(thisLive, {
          inlineVolume: true,
        });
        live.volume.setVolume(0.2);

        const player = createAudioPlayer();
        connection.subscribe(player);

        player.play(live);
		collector.stop()

        interaction.followUp({
          content: `${client.emoji.Broadcast} ${locale.radio_launch} ${interaction.member.voice.channel}`,
        });

        const int = setInterval(() => {
          if (
            interaction?.member?.voice?.channel?.members?.size ===
            (0 || undefined)
          ) {
            clearInterval(int);
            getVoiceConnection(interaction.guildId).disconnect();
          }
        }, 5000);
      });
    }
    if (interaction.values[0] === "third_select_radio") {
	  await interaction.deferReply();

	  const isVoc = interaction.guild.channels.cache.find((channel) => channel.type == ChannelType.GuildVoice && !channel.members.has(interaction.user.id) && channel.members.has(client.user.id));

	  const vcEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_notinvc}`);
	  if (!interaction.member.voice.channel) return interaction.editReply({ embeds: [vcEmbed] });

	  const alreadyVCEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_already}`);
	  if (isVoc) return interaction.editReply({ embeds: [alreadyVCEmbed] });

	  const selectRadioRow = new ActionRowBuilder()
		  .addComponents(
			  new StringSelectMenuBuilder()
				  .setCustomId('select')
				  .setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
				  .addOptions([
					  {
						  label: 'Nrj',
						  description: `${locale.radio_sm_description} NRJ (France).`,
						  value: 'first',
						  emoji: '<:radio_nrj:962000149587046520> ',
					  },
					  {
						  label: 'Skyrock',
						  description: `${locale.radio_sm_description} Skyrock (France).`,
						  value: 'second',
						  emoji: '<:radio_skyrock:962000284677189633>',
					  },
					  {
						  label: 'RFM',
						  description: `${locale.radio_sm_description} RFM (France).`,
						  value: 'third',
						  emoji: '<:radio_rfm:962000348497707078> ',
					  },
					  {
						  label: 'Rap FR Gold',
						  description: `${locale.radio_sm_description} Rap FR Gold (France).`,
						  value: 'fourth',
						  emoji: '<:radio_rap:1065261871332065310>',
					  },
					  {
						  label: 'Radio Classique',
						  description: `${locale.radio_sm_description} Radio Classique (France).`,
						  value: 'fifth',
						  emoji: '<:radio_classique:962003647569469491>',
					  },
					  {
						  label: 'Mouv\'',
						  description: `${locale.radio_sm_description} Mouv' (France).`,
						  value: 'sixth',
						  emoji: '<:radio_mouv:1065264506684571728>',
					  },
					  {
						  label: 'NOSTALGIE',
						  description: `${locale.radio_sm_description} Nostalgie (France).`,
						  value: 'seventh',
						  emoji: '<:radio_nostalgie:962005670247399444>',
					  },
					  {
						  label: 'Chérie FM',
						  description: `${locale.radio_sm_description} Chérie FM (France).`,
						  value: 'eight',
						  emoji: '<:radio_cheriefm:962013498118897694>',
					  },
					  {
						  label: 'FUNRADIO',
						  description: `${locale.radio_sm_description} Funradio (France).`,
						  value: 'nineth',
						  emoji: '<:radio_funradio:962017789009346640>',
					  },
					  {
						  label: 'MeGaMoV',
						  description: `${locale.radio_sm_description} MeGaMoV (France).`,
						  value: 'tenth',
						  emoji: '<:radio_megamov:962048009292615810>',
					  },
					  {
						  label: 'NRJ METAL',
						  description: `${locale.radio_sm_description} NRJ METAL (France).`,
						  value: 'eleventh',
						  emoji: '<:radio_nrjmetal:962109888736141352>',
					  },
					  {
						  label: 'France Info',
						  description: `${locale.radio_sm_description} France Info (France).`,
						  value: 'twelfth',
						  emoji: '<:radio_franceinfo:962113327692124160>',
					  },
					  {
						  label: 'Radio France Musique La Baroque',
						  description: `${locale.radio_sm_description} radio France Musique La Baroque (France).`,
						  value: 'thirteenth',
						  emoji: '<:france_baroque:998197320539713556>',
					  },
					  {
						  label: 'France Flip',
						  description: `${locale.radio_sm_description} France Flip (France).`,
						  value: 'fourteenth',
						  emoji: '<:flip:1040638653728309368>',
					  },
					  {
						  label: 'EuroDance 90',
						  description: `${locale.radio_sm_description} EuroDance 90 (France).`,
						  value: 'fifteenth',
						  emoji: '<:eurodance90:1062826689438154752>',
					  },
				  ]),
		  );

		  const commands = await client.application.commands.fetch();
		  const inviteCMD = commands.filter(command => !command.name.startsWith('radio-') && !command.name.startsWith('radioinfo-') && !command.name.startsWith('botinfo') && !command.name.startsWith('help') && !command.name.startsWith('support') && !command.name.startsWith('ping') && !command.name.startsWith('radiolist') && !command.name.startsWith('vote') && !command.name.startsWith('set-language') && !command.name.startsWith('about') && !command.name.startsWith('legal') && !command.name.startsWith('donate') && !command.name.startsWith('acknowledgements'));
		  const supportCMD = commands.filter(command => !command.name.startsWith('radio-') && !command.name.startsWith('radioinfo-') && !command.name.startsWith('botinfo') && !command.name.startsWith('help') && !command.name.startsWith('invite') && !command.name.startsWith('ping') && !command.name.startsWith('radiolist') && !command.name.startsWith('vote') && !command.name.startsWith('set-language') && !command.name.startsWith('about') && !command.name.startsWith('legal') && !command.name.startsWith('donate') && !command.name.startsWith('acknowledgements'));
	  const welcomeEmbed = new EmbedBuilder()
		  .setColor(client.color.white)
		  .setDescription(stripIndents`
		  ${client.emoji.Beta} ${locale.radio_w_l1}

		  ${client.emoji.Tools} ${locale.radio_w_l2.replace('{{Radio}}', 'Europe')}

		  ${client.emoji.Broadcast} ${locale.radio_w_l3}

		  ${client.emoji.Config} ${locale.radio_w_l4} : ${inviteCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}

		  ${client.emoji.Sciences} ${locale.radio_w_l5} **${selectRadioRow.components[0].options.length}** Europe ${locale.radio_w_l6}
		  
		  ${client.emoji.Star} ${locale.radio_w_l7} : ${supportCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}
		  `)
		  .setThumbnail(interaction.user.displayAvatarURL({ size: 2048 }))
		  .setFooter({
			  text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
			  iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
		  });

	  await interaction.editReply({ embeds: [welcomeEmbed], components: [selectRadioRow] });

	  const collector = await interaction.channel.createMessageComponentCollector({ componentType: ComponentType.SelectMenu, time : 3600000, max: 999999});

	  collector.on('collect', async (c) => {
		  const links = {
			  first: 'http://cdn.nrjaudio.fm/audio1/fr/30001/aac_64.mp3',
			  second: 'http://www.skyrock.fm/stream.php/tunein16_128mp3.mp3',
			  third: 'https://ais-live.cloud-services.paris:8443/rfm.mp3',
			  fourth: 'http://gene-wr06.ice.infomaniak.ch/gene-wr06.mp3',
			  fifth: 'http://radioclassique.ice.infomaniak.ch/radioclassique-high.mp3',
			  sixth: 'http://direct.mouv.fr/live/mouv-midfi.mp3',
			  seventh: 'http://scdn.nrjaudio.fm/adwz2/fr/30601/mp3_128.mp3?origine=fluxradios',
			  eight: 'http://scdn.nrjaudio.fm/adwz2/fr/30201/mp3_128.mp3?origine=fluxradios',
			  nineth: 'http://streamer-02.rtl.fr/fun-1-44-128?listen=webCwsBCggNCQgLDQUGBAcGBg',
			  tenth: 'http://stream-128.megamov.radio.fm',
			  eleventh: 'https://scdn.nrjaudio.fm/fr/30079/mp3_128.mp3?origine=fluxradios&cdn_path=adswizz_lbs9&adws_out_a1&access_token=b8a1e4b59e024447b9307dad9baeaaf4',
			  twelfth: 'http://icecast.radiofrance.fr/franceinfo-hifi.aac',
			  thirteenth: 'http://icecast.radiofrance.fr/francemusiquebaroque-hifi.aac',
			  fourteenth :'http://icecast.radiofrance.fr/fip-midfi.mp3',
			  fifteenth : 'https://stream-eurodance90.fr/radio/8000/128.mp3',
		  };

		  const thisLive = links[c.values[0]];

		  const connection = joinVoiceChannel({
			  channelId: interaction.member.voice.channel.id,
			  guildId: interaction.guild.id,
			  adapterCreator: interaction.guild.voiceAdapterCreator,
		  });

		  const live = createAudioResource(thisLive, {
			  inlineVolume: true,
		  });
		  live.volume.setVolume(0.2);

		  const player = createAudioPlayer();
		  connection.subscribe(player);

		  player.play(live);
		  collector.stop();

		  interaction.followUp({ content: `${client.emoji.Broadcast} ${locale.radio_launch} ${interaction.member.voice.channel}` });

		  const int = setInterval(() => {
			  if (interaction?.member?.voice?.channel?.members?.size === (0 || undefined)) {
				  clearInterval(int);
				  getVoiceConnection(interaction.guildId).disconnect();
			  }
		  }, 5000);
	  });
    }
    if (interaction.values[0] === "four_select_radio") {
		await interaction.deferReply();

		const isVoc = interaction.guild.channels.cache.find((channel) => channel.type == ChannelType.GuildVoice && !channel.members.has(interaction.user.id) && channel.members.has(client.user.id));

		const vcEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_notinvc}`);
		if (!interaction.member.voice.channel) return interaction.editReply({ embeds: [vcEmbed] });

		const alreadyVCEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_already}`);
		if (isVoc) return interaction.editReply({ embeds: [alreadyVCEmbed] });

		const selectRadioRow = new ActionRowBuilder()
			.addComponents(
				new StringSelectMenuBuilder()
					.setCustomId('select')
					.setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
					.addOptions([
						{
							label: "Jazz on Radio",
							description: `${locale.radio_sm_description} Jazz on Radio.`,
							value: "first",
							emoji: "<:radio_jazz:1053374965900124220>",
						},
						{
							label: "Lofi Radio",
							description: `${locale.radio_sm_description} Lofi Radio.`,
							value: "second",
							emoji: "<:lofi_radio:998203638969290773>",
						},
						{
							label: "Nightwave Plaza",
							description: `${locale.radio_sm_description} Nightwave Plaza.`,
							value: "third",
							emoji: "<:plazaone:1020823721285537803>",
						},
						{
							label: "Last.fm EuroBeat",
							description: `${locale.radio_sm_description} Last.fm EuroBeat.`,
							value: "fourth",
							emoji: "<:eurobeat:1039706824737296444>",
						},
						{
							label: "TechnoBase.FM",
							description: `${locale.radio_sm_description} TechnoBase.FM.`,
							value: "fifth",
							emoji: "<:TechnoBase:1039912203979083836>",
						},
						{
							label: "Proton Radio",
							description: `${locale.radio_sm_description} Proton Radio.`,
							value: "sixth",
							emoji: "<:ProtonRadio:1039913384310747228>",
						},
						{
							label: "AnimeRadio.de",
							description: `${locale.radio_sm_description} AnimeRadio.de.`,
							value: "seventh",
							emoji: "<:AnimeRadio:1040693633470447718>",
						},
						{
							label: "Happy Christmas Radio",
							description: `${locale.radio_sm_description} Happy Christmas Radio.`,
							value: "eighth",
							emoji: "<:HappyChristmasRadio:1040664309207941170>",
						},
						{
							label: "Radio Box",
							description: `${locale.radio_sm_description} Radio Box.`,
							value: "ninth",
							emoji: "<:radio_box_logo:1053353881121341450>",
						},
						{
							label: "80s Hits - Open FM",
							description: `${locale.radio_sm_description} 80s Hits - Open FM.`,
							value: "tenth",
							emoji: "<:80_hits:1053379993780092998>",
						},
						{
							label: "Monstercat - Electronic Music",
							description: `${locale.radio_sm_description} Monstercat - Electronic Music.`,
							value: "eleventh",
							emoji: "<:monstercat:1055134867106562078>",
						},
						{
							label: "Marijos radijas",
							description: `${locale.radio_sm_description} Marijos radijas.`,
							value: "twelfth",
							emoji: "<:Marijosradijas:1063505247760302080>",
						},
					]),
			);
		
		const welcomeEmbed = new EmbedBuilder()
			.setColor(client.color.white)
			.setDescription(stripIndents`
			${client.emoji.Beta} ${locale.radio_w_l1}

			${client.emoji.Tools} ${locale.radio_w_l8}

			${client.emoji.Broadcast} ${locale.radio_w_l3}
			
			${client.emoji.Config} ${locale.radio_w_l4} : ${inviteCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}

			${client.emoji.Sciences} ${locale.radio_w_l5} **${selectRadioRow.components[0].options.length}** ${locale.radio_w_l6}
			
			${client.emoji.Star} ${locale.radio_w_l7} : ${supportCMD.map(c => `</${c.name}:${c.id}>`).join(' ')} 
			`)
			.setThumbnail(interaction.user.displayAvatarURL({ size: 2048 }))
			.setFooter({
				text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
				iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
			});

		await interaction.editReply({ embeds: [welcomeEmbed], components: [selectRadioRow] });

		const collector = await interaction.channel.createMessageComponentCollector({ componentType: ComponentType.SelectMenu, time : 3600000, max: 999999});

		collector.on('collect', async (c) => {
			const links = {
				first: 'https://0n-jazz.radionetz.de/0n-jazz.aac',
				second: 'https://play.streamafrica.net/lofiradio',
				third: "http://radio.plaza.one/mp3",
				fourth: "http://stream.laut.fm/eurobeat",
				fifth: "http://lw2.mp3.tb-group.fm/tb.mp3",
				sixth: "https://icecast.protonradio.com",
				seventh: "http://stream.animeradio.de/animeradio.mp3",
				eighth: "https://radio1.streamserver.link/radio/8070/hcr-aac",
				ninth: "http://5.105.6.23:8000/radio-box.mp3",
				tenth: "https://stream.open.fm/3",
				eleventh: "http://ice55.securenetsystems.net/DASH63",
				twelfth: "http://stream.marijosradijas.lt:8001/marijosradijas.mp3",
			};

			const thisLive = links[c.values[0]];

			const connection = joinVoiceChannel({
				channelId: interaction.member.voice.channel.id,
				guildId: interaction.guild.id,
				adapterCreator: interaction.guild.voiceAdapterCreator,
			});

			const live = createAudioResource(thisLive, {
				inlineVolume: true,
			});
			live.volume.setVolume(0.2);

			const player = createAudioPlayer();
			connection.subscribe(player);

			player.play(live);
			collector.stop();

			interaction.followUp({ content: `${client.emoji.Broadcast} ${locale.radio_launch} ${interaction.member.voice.channel}` });

			const int = setInterval(() => {
				if (interaction?.member?.voice?.channel?.members?.size === (0 || undefined)) {
					clearInterval(int);
					getVoiceConnection(interaction.guildId).disconnect();
				}
			}, 5000);
		});
    }
    if (interaction.values[0] === "five_select_radio") {
		await interaction.deferReply();

		const isVoc = interaction.guild.channels.cache.find((channel) => channel.type == ChannelType.GuildVoice && !channel.members.has(interaction.user.id) && channel.members.has(client.user.id));

		const vcEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_notinvc}`);
		if (!interaction.member.voice.channel) return interaction.editReply({ embeds: [vcEmbed] });

		const alreadyVCEmbed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Warn} ${locale.radio_already}`);
		if (isVoc) return interaction.editReply({ embeds: [alreadyVCEmbed] });

		const selectRadioRow = new ActionRowBuilder()
			.addComponents(
				new StringSelectMenuBuilder()
					.setCustomId('select')
					.setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
					.addOptions([
						{
							label: 'Radio Record',
							description: `${locale.radio_sm_description} Radio Record.`,
							value: 'first',
							emoji: '<:radio_radiorecord:989516461884186684>',
						},
						{
							label: 'Russian Mix',
							description: `${locale.radio_sm_description} Russian Mix.`,
							value: 'second',
							emoji: '<:radio_radiorecord:989516461884186684>',
						},
						{
							label: 'Пи FM',
							description: `${locale.radio_sm_description} Пи FM.`,
							value: 'third',
							emoji: '<:PFM:1040754498609614858>',
						},
						{
							label: 'HypeFM',
							description: `${locale.radio_sm_description} HypeFM.`,
							value: 'fourth',
							emoji: '<:HypeFM:1040755059224481913>',
						},
						{
							label: 'RADIO R',
							description: `${locale.radio_sm_description} RADIO R.`,
							value: 'fifth',
							emoji: '<:radior:1063118002410758154>',
						},
					]),
			);

		const welcomeEmbed = new EmbedBuilder()
			.setColor(client.color.white)
			.setDescription(stripIndents`
			${client.emoji.Beta} ${locale.radio_w_l1}

			${client.emoji.Tools} ${locale.radio_w_l2.replace('{{Radio}}', 'Russian')}

			${client.emoji.Broadcast} ${locale.radio_w_l3}

			${client.emoji.Config} ${locale.radio_w_l4} : ${inviteCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}

			${client.emoji.Sciences} ${locale.radio_w_l5} **${selectRadioRow.components[0].options.length}** Russian ${locale.radio_w_l6}
			
			${client.emoji.Star} ${locale.radio_w_l7} : ${supportCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}
			`)
			.setThumbnail(interaction.user.displayAvatarURL({ size: 2048 }))
			.setFooter({
				text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
				iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
			});

		await interaction.editReply({ embeds: [welcomeEmbed], components: [selectRadioRow] });

		const collector = await interaction.channel.createMessageComponentCollector({ componentType: ComponentType.SelectMenu, time : 3600000, max: 999999});

		collector.on('collect', async (c) => {
			const links = {
				first: 'https://radiorecord.hostingradio.ru/rr_main96.aacp',
				second: 'https://radiorecord.hostingradio.ru/rus96.aacp',
				third: 'https://cdn.pifm.ru/mp3',
				fourth: 'https://hfm.amgradio.ru/HypeFM',
				fifth: 'https://stream1.rusradio.lt/rrb128.mp3'
			};

			const thisLive = links[c.values[0]];

			const connection = joinVoiceChannel({
				channelId: interaction.member.voice.channel.id,
				guildId: interaction.guild.id,
				adapterCreator: interaction.guild.voiceAdapterCreator,
			});

			const live = createAudioResource(thisLive, {
				inlineVolume: true,
			});
			live.volume.setVolume(0.2);

			const player = createAudioPlayer();
			connection.subscribe(player);

			player.play(live);
			collector.stop();

			interaction.followUp({ content: `${client.emoji.Broadcast} ${locale.radio_launch} ${interaction.member.voice.channel}` });

			const int = setInterval(() => {
				if (interaction?.member?.voice?.channel?.members?.size === (0 || undefined)) {
					clearInterval(int);
					getVoiceConnection(interaction.guildId).disconnect();
				}
			}, 5000);
		});
    }
  }
  catch(err) {
	return interaction.channel.send('..')
  }
}
}
