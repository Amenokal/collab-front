const { Collection, InteractionType } = require('discord.js');
const { stripIndents } = require('common-tags');
const db = require('quick.db');

const cooldowns = new Collection();

module.exports = {
	name: 'interactionCreate',
	category: 'guild',
	enabled: true,
	once: false,
	run: async (interaction) => {
		const client = interaction.client;

		if (interaction.type === InteractionType.ApplicationCommand) {
			const findLocale = await db.fetch(`locale_${interaction.guild.id}`);
			if (!findLocale) {
				await db.set(`locale_${interaction.guild.id}`, 'en');
			}

			const locale = await client.util.getServerLocale(interaction, findLocale);

			const command = client.commands.get(interaction.commandName);

			if (interaction.user.bot) return;

			if (!command) return await interaction.reply({ content: `${client.emoji.Warn} ${locale.cmd_notfound}`, ephemeral: true }) && client.commands.delete(interaction.commandName);

			if (!cooldowns.has(command.name)) {
				cooldowns.set(command.name, new Collection());
			}

			const now = Date.now();
			const timestamps = cooldowns.get(command.name);
			const cooldownAmount = Math.floor(command.cooldown) * 1000;

			if (!timestamps.has(interaction.user.id)) {
				timestamps.set(interaction.user.id, now);
				setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);
			}
			else {
				const expirationTime = timestamps.get(interaction.user.id) + cooldownAmount;
				const timeLeft = (expirationTime - now) / 1000;
				if (now < expirationTime && timeLeft > 0.9) {
					return interaction.reply({ content: `${client.emoji.Warn} » ${locale.cmd_cooldown1} **${timeLeft.toFixed(0)} ${locale.cmd_cooldown3}** ${locale.cmd_cooldown2} : **${command.name}**.`, ephemeral: true });
				}
				timestamps.set(interaction.user.id, now);
				setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);
			}

			try {
				command.run(client, interaction, locale);
			}
			catch (e) {
				return await interaction.reply({ content: stripIndents`
                **${locale.cmd_error_int}**
                
                \`\`\`
                ${e.message}
                \`\`\`
                `, ephemeral: true });
			}
		}
	},
};
