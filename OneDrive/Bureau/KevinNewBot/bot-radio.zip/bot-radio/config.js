module.exports = {
	defaultLocale: 'en',
	voteURL: 'https://top.gg/bot/961787029841145979',
	supportServerURL: 'https://discord.gg/3vBXg4VvM5',
	inviteURL: 'https://discord.com/api/oauth2/authorize?client_id=961787029841145979&permissions=689379863920&scope=bot%20applications.commands',
	tosURL: 'https://radio-box.dev/terms-and-conditions',
	ppURL: 'https://radio-box.dev/privacy-policy',
	donateURL: 'https://www.buymeacoffee.com/UltraLion',
};