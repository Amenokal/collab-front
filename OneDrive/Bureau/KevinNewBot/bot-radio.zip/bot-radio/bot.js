const BotClient = require("./handler/Client");
require("dotenv").config();

const client = new BotClient(process.env.TOKEN);
require("./handler/Command")(client);
require("./handler/Event")(client);

console.log("» Bot is now starting up!");

client.login();
