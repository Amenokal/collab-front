const fs = require("fs");
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
require('dotenv').config();

module.exports = async (client) => {
  let commandData = [];
  fs.readdirSync("./commands/").forEach(async (category) => {
    const commands = fs
      .readdirSync(`./commands/${category}/`)
      .filter((cmd) => cmd.endsWith(".js"));

    for (const command of commands) {
      const cmd = require(`../commands/${category}/${command}`);
      const cmdData = cmd.data.toJSON();
      commandData.push(cmdData);

      const cmdSet = {
        name: cmdData.name,
        type: cmdData.type,
        description: cmdData.description,
        options: cmdData.options,
        usage: cmd.usage,
        cooldown: cmd.cooldown,
        category: cmd.category,
        run: cmd.run,
      };
      client.commands.set(cmdSet.name, cmdSet);
    }
  });
 
  console.log("» Slash Commands and Context Menus have now loaded!");

  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
  const clientId = process.env.CLIENT_ID;

  console.log('» Started refreshing Slash Commands and Context Menus...');

  await rest.put(
    Routes.applicationCommands(clientId),
    { body: commandData },
  ).then(() => {
    console.log('» Slash Commands and Context Menus have now been deployed.\n These may take up to an hour to fan out to all servers and users.');
  });
};
