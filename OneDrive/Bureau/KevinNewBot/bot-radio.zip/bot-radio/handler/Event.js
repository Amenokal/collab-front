const fs = require("fs");

module.exports = (client) => {
  fs.readdirSync("./events/").forEach(async (category) => {
    const events = fs
      .readdirSync(`./events/${category}/`)
      .filter((evt) => evt.endsWith(".js"));

    for (const event of events) {
      const e = require(`../events/${category}/${event}`);

      client.events.set(e.name, e);
      e.once
        ? client.once(e.name, e.run.bind(event))
        : client.on(e.name, e.run);
    }
  });

  console.log("» Events have now loaded!");
};
