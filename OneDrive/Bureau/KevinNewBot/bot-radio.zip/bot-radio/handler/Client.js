const {
  Client,
  GatewayIntentBits,
  Partials,
  ActivityType,
} = require("discord.js");
const { Collection } = require("@discordjs/collection");

const colors = require("../assets/json/color.json");
const emoji = require("../assets/json/emoji.json");
const Util = require("../util/Util");

module.exports = class BotClient extends Client {
  constructor(...opt) {
    super({
      opt,
      allowedMentions: {
        parse: ["users", "roles"],
        repliedUser: true,
      },
      partials: [
        Partials.GuildMember,
        Partials.Message,
        Partials.Channel,
        Partials.User,
        Partials.Reaction,
      ],
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates,
      ],
      presence: {
        status: "online",
        activities: [
          { name: "Bot is now starting up...", type: ActivityType.Playing },
        ],
      },
    });
    this.version = require("../package.json").version;
    this.name = require("../package.json").name;
    this.config = require("../config");
    this.emoji = emoji;
    this.color = colors;
    this.util = new Util(this);

    this.commands = new Collection();
    this.events = new Collection();
    this.cooldowns = new Collection();
  }

  async login() {
    await super.login(process.env.TOKEN);
  }
};
