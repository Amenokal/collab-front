const { EmbedBuilder } = require("discord.js");
const { stripIndents } = require("common-tags");
const fs = require("fs");

module.exports = class BotUtil {
  constructor(client) {
    this.client = client;
  }

  // eslint-disable-next-line no-unused-vars
  CattoEmbed(client, user, desc, title = "", thumbnail = "") {
    const embed = new EmbedBuilder()
      .setAuthor({
        name: `${user.tag}`,
        iconURL: user.displayAvatarURL({ size: 2048 }),
      })
      .setDescription(
        stripIndents`
			${desc}
			`
      )
      .setColor(client.color.green)
      .setFooter({
        text: "©️ Radio Box",
      })
      .setThumbnail(user.displayAvatarURL({ size: 2048 }));

    if (title) embed.setTitle(title);
    if (thumbnail) embed.setThumbnail(thumbnail);

    return embed;
  }

  timeoutDelete(message, time = 10) {
    if (!message) return;
    const t = time * 1000;
    setTimeout(() => message.delete(), t);
  }

  async getServerLocale(interaction, locale) {
    if (locale.startsWith("en")) locale = "en";

    const languages = fs
      .readdirSync("./assets/languages")
      .filter((file) => file.endsWith(".js"))
      .map((file) => file.replace(".js", ""));
    if (!languages.includes(locale)) locale = "en";

    const searchLocale = require(`../assets/languages/${locale}.js`);

    return searchLocale;
  }
};
