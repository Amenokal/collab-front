const {
  ActionRowBuilder,
  ButtonBuilder,
  EmbedBuilder,
  ButtonStyle,
} = require("discord.js");
const { radios } = require("./radios");

module.exports = async (interaction) => {
  const choice = interaction.options.getString("name");

  const radio = radios.find(
    (rad) => rad.name.toUpperCase() === choice.toUpperCase()
  );

  if (!radio)
    return interaction.editReply({
      content: `\`\`\`No info found for radio ${choice}\`\`\``,
    });

  const embed = new EmbedBuilder()
    .setTitle(radio.name)
    .addFields(
      {
        name: "Frequency",
        value: `${radio.frequency}`,
        inline: true,
      },
      {
        name: "Country",
        value: `${radio.country}`,
        inline: true,
      },
      {
        name: "Tags",
        value: `${radio.tags}`,
        inline: false,
      }

    )
    .setThumbnail(radio.logo);

  const buttonRow = new ActionRowBuilder()
  .addComponents(
    new ButtonBuilder()
    .setEmoji("🌐")
    .setLabel("Website")
    .setStyle(ButtonStyle.Link)
    .setURL(radio.website),
      
      new ButtonBuilder()
      .setEmoji("📻")
      .setLabel("WebCast")
      .setStyle(ButtonStyle.Link)
      .setURL(radio.webcast)
  );
  

  return await interaction.reply({ embeds: [embed], components: [buttonRow] });
};
