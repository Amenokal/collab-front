module.exports.radios = [
  
  { //Africa
    name: "Hot 102.7 FM",
    logo: "https://hot1027.co.za/wp-content/uploads/2020/06/cropped-Fac-32x32.png",
    website: "https://hot1027.co.za/",
    webcast: 'https://edge.iono.fm/xice/57_high.aac',
    frequency: 102.7,
    country: "South Africa",
    tags: "N/A"
  },
  {
    name: "Magic 828",
    logo: "https://magic828.co.za/wp-content/uploads/2018/11/magic-favicon.png",
    website: "https://magic828.co.za/",
    webcast: 'http://cast.fabrik.fm:8106/',
    frequency: 828,
    country: "South Africa",
    tags: "N/A"
  },
  {
    name: 'Jacaranda FM',
    logo: `https://turntable.kagiso.io/core/images/jacaranda/apple-touch-icon.png`,
    website: 'https://www.jacarandafm.com/',
    webcast: 'https://edge.iono.fm/xice/jacarandafm_live_medium.aac',
    frequency: "93.9 / 97.1",
    country: "South Africa",
    tags: "Adult Contemporary, Pop, Regional Radio, Talk"
  },
//Asia
  {
    name: 'Listen.Moe JPop',
    logo: `https://listen.moe//favicon.ico`,
    website: 'https://listen.moe/',
    webcast: 'https://listen.moe/stream',
    frequency: "N/A",
    country: "Japan",
    tags: "Jpop"
  },
  {
    name: 'Listen.Moe Kpop',
    logo: `https://listen.moe//favicon.ico`,
    website: 'https://listen.moe/',
    webcast: 'https://listen.moe/kpop/stream',
    frequency: "N/A",
    country: "Japan",
    tags: "Kpop"
  },
  {
    name: 'Kishiwada Radio',
    logo: `https://www.radiokishiwada.jp/data/html/template/default/img/common/favicon.ico`,
    website: 'https://www.radiokishiwada.jp',
    webcast: 'http://61.89.201.27:8000/radikishi.mp3',
    frequency: "79.7",
    country: "Japan",
    tags: "N/A"
  },
//Europe
  {
    name: 'Nrj',
    logo: `https://www.nrj.fr/uploads/assets/nrj/icons/apple-icon-120x120.png`,
    website: 'http://www.nrj.fr/',
    webcast: 'http://cdn.nrjaudio.fm/audio1/fr/30001/aac_64.mp3',
    frequency: "https://www.nrj.fr/frequences",
    country: "France",
    tags: "N/A"
  },
  {
    name: 'Skyrock',
    logo: `https://www.radio.fr/images/broadcasts/c1/bb/8302/3/c300.png`,
    website: 'https://skyrock.fm/',
    webcast: 'http://www.skyrock.fm/stream.php/tunein16_128mp3.mp3',
    frequency: "https://skyrock.fm/skyrock/frequence",
    country: "France",
    tags: "rap"
  },
  {
    name: 'RFM',
    logo: `http://cdn-rfm.lanmedia.fr/bundles/rfmintegration/images/logoRFM.png`,
    website: 'http://www.rfm.fr',
    webcast: 'https://ais-live.cloud-services.paris:8443/rfm.mp3',
    frequency: "http://www.rfm.fr/frequences",
    country: "France",
    tags: "Chansons Françaises, Pop"
  },
  {
    name: 'Rap FR Gold',
    logo: `https://generations.fr/media/radio/rap_fr1.webp`,
    website: 'http://generations.fr/',
    webcast: 'http://gene-wr06.ice.infomaniak.ch/gene-wr06.mp3',
    frequency: "N/A",
    country: "France/Paris",
    tags: "Rap"
  },
  {
    name: 'Radio Classique',
    logo: `https://www.radioclassique.fr/wp-content/themes/radioclassique/favicons/apple-touch-icon.png`,
    website: 'https://www.radioclassique.fr/',
    webcast: 'http://radioclassique.ice.infomaniak.ch/radioclassique-high.mp3',
    frequency: "https://www.radioclassique.fr/frequences-fm/",
    country: "France",
    tags: "Classical"
  },
  {
    name: "Mouv'",
    logo: `https://i.imgur.com/aFUjPeD.png`,
    website: 'http://mouv.fr',
    webcast: 'http://direct.mouv.fr/live/mouv-midfi.mp3',
    frequency: "https://radioenlignefrance.com/frequence/radio-mouv",
    country: "France",
    tags: "Public Radio, Radio France"
  },
  {
    name: 'NOSTALGIE',
    logo: `https://www.nostalgie.fr/uploads/assets/nostalgie/icons/apple-icon-120x120.png`,
    website: 'http://www.nostalgie.fr/',
    webcast: 'http://scdn.nrjaudio.fm/adwz2/fr/30601/mp3_128.mp3?origine=fluxradio',
    frequency: "https://www.nostalgie.fr/frequences",
    country: "France",
    tags: "N/A"
  },
  {
    name: 'Chérie FM',
    logo: `https://www.cheriefm.fr/uploads/assets/cherie/icons/apple-icon-120x120.png`,
    website: 'http://www.cheriefm.fr/',
    webcast: 'http://cdn.nrjaudio.fm/audio1/fr/30201/mp3_128.mp3',
    frequency: "https://www.cheriefm.fr/frequences-cheriefm",
    country: "France",
    tags: "Musique"
  },
  {
    name: 'FUNRADIO',
    logo: `https://www.radio.fr/images/broadcasts/9c/41/7219/1/c300.png`,
    website: 'https://www.funradio.fr/',
    webcast: 'http://streamer-02.rtl.fr/fun-1-44-128?listen=webCwsBCggNCQgLDQUGBAcGBg',
    frequency: "https://www.funradio.fr/frequences",
    country: "France",
    tags: "Electro"
  },
  {
    name: 'MeGaMoV',
    logo: `https://megamov.radio.fm/img/megamov.png`,
    website: 'https://megamov.fr',
    webcast: 'http://stream-128.megamov.radio.fm',
    frequency: "N/A",
    country: "France",
    tags: "Electro"
  },
  {
    name: 'NRJ METAL',
    logo: `https://www.nrj.fr/uploads/assets/nrj/icons/apple-icon-120x120.png`,
    website: 'https://www.nrj.fr/webradios/mur-des-radios/nrj-metal',
    webcast: 'https://scdn.nrjaudio.fm/fr/30079/mp3_128.mp3?origine=fluxradios&cdn_path=adswizz_lbs9&adws_out_a1&access_token=b8a1e4b59e024447b9307dad9baeaaf4',
    frequency: "N/A",
    country: "France",
    tags: "metal"
  },
  {
    name: 'France Info',
    logo: `https://upload.wikimedia.org/wikipedia/fr/thumb/1/18/France_Info_-_2008.svg/768px-France_Info_-_2008.svg.png`,
    website: 'https://www.francetvinfo.fr/',
    webcast: 'http://icecast.radiofrance.fr/franceinfo-hifi.aac',
    frequency: "https://www.radiofrance.com/frequences",
    country: "France",
    tags: "Information"
  },
  {
    name: 'France Musique La Baroque',
    logo: `https://www.radiofrance.fr/dist/favicons/francemusique/favicon.png`,
    website: 'https://www.francemusique.fr/radios-thematiques/la-baroque',
    webcast: 'http://icecast.radiofrance.fr/francemusiquebaroque-hifi.aac',
    frequency: "N/A",
    country: "France",
    tags: "Classical, Public Radio, Radio France"
  },
  {
    name: 'France Flip',
    logo: `https://www.radiofrance.fr/dist/favicons/fip/favicon.png`,
    website: 'https://www.radiofrance.fr/fip',
    webcast: 'http://icecast.radiofrance.fr/fip-midfi.mp3',
    frequency: "https://www.radiofrance.com/frequences",
    country: "France",
    tags: "N/A"
  },
  {
    name: 'EuroDance 90',
    logo: `https://co.radio.net/images/broadcasts/1a/9e/16136/2/c300.png`,
    website: 'https://eurodance90.fr',
    webcast: 'https://stream-eurodance90.fr/radio/8000/128.mp3',
    frequency: "N/A",
    country: "France",
    tags: "Dancefloor, Electronic Dance Music, Eurodance, Pop Dance, Pop Music"
  },
//Other
  {
    name: 'Jazz on Radio',
    logo: `https://www.0nradio.com/logos/0n-jazz_600x600.jpg`,
    website: 'https://www.0nradio.com/',
    webcast: 'https://0n-jazz.radionetz.de/0n-jazz.aac',
    frequency: "N/A",
    country: "Germany",
    tags: "Jazz, Smooth Jazz, Swing"
  },
  {
    name: 'Lofi Radio',
    logo: `https://i.ibb.co/2Sxyv6t/boxlofi-1-555x555x0x0x555x555x1653681083.jpg`,
    website: 'https://boxradio.net',
    webcast: 'https://play.streamafrica.net/lofiradio',
    frequency: "N/A",
    country: "The United Kingdom Of Great Britain And Northern Ireland",
    tags: "Chill, Lofi"
  },
  {
    name: 'Nightwave Plaza',
    logo: `https://cdn.discordapp.com/icons/315683286242557955/396f53740a6cbe3e0c9fd60c0993b931.webp?size=512`,
    website: 'http://plaza.one/',
    webcast: 'http://radio.plaza.one/mp3',
    frequency: "N/A",
    country: "Japan",
    tags: "Aesthetic, Chillwave, Futurefunk, Lofi, Vaporwave"
  },
  {
    name: 'Last.fm EuroBeat',
    logo: `https://i.imgur.com/XWGH9g5.jpg`,
    website: 'https://laut.fm/eurobeat',
    webcast: 'http://stream.laut.fm/eurobeat',
    frequency: "N/A",
    country: "Germany",
    tags: "EuroBeat"
  },
  {
    name: 'TechnoBase.FM',
    logo: `https://www.technobase.fm/media/icons/tb/apple-touch-icon.png`,
    website: 'https://technobase.fm/',
    webcast: 'http://lw2.mp3.tb-group.fm/tb.mp3',
    frequency: "N/A",
    country: "Germany",
    tags: "Dance, Eurodance, Handsup, Happy Hardcore, Hardcore, Jumpstyle, Techno"
  },
  {
    name: 'Proton Radio',
    logo: `https://d3kle7qwymxpcy.cloudfront.net/images/broadcasts/cf/a4/6484/c175.png`,
    website: 'https://www.protonradio.com',
    webcast: 'https://icecast.protonradio.com',
    frequency: "N/A",
    country: "The United States Of America",
    tags: "Breaks, Electro, House, Minimal, Progressive, Techno"
  },
  {
    name: 'AnimeRadio.de',
    logo: `https://www.animeradio.de/img/favicon.png`,
    website: 'https://www.animeradio.de',
    webcast: 'http://stream.animeradio.de/animeradio.mp3',
    frequency: "N/A",
    country: "Germany",
    tags: "Anime"
  },
  {
    name: 'Happy Christmas Radio',
    logo: `https://www.happychristmasradio.net/site_hcr/images/favicon/apple-touch-icon.png`,
    website: 'https://www.happychristmasradio.net/',
    webcast: 'https://radio1.streamserver.link/radio/8070/hcr-aac',
    frequency: "N/A",
    country: "Canada",
    tags: "Christmas, Christmas Music, Holiday, Xmas"
  },
  {
    name: 'Radio Box',
    logo: `https://i.imgur.com/fSz1Fta.png`,
    website: 'https://radio-box.dev',
    webcast: 'http://5.105.6.23:8000/radio-box.mp3',
    frequency: "N/A",
    country: "France",
    tags: "Electro"
  },
  {
    name: '80s Hits - Open FM',
    logo: `https://i.imgur.com/EUHtmjs.png`,
    website: 'https://open.fm/stacje-muzyczne/80s-hits',
    webcast: 'https://stream.open.fm/3',
    frequency: "N/A",
    country: "Poland",
    tags: "80s, Hits, Music"
  },
  {
    name: 'Monstercat - Electronic Music',
    logo: `https://s3.amazonaws.com/dashradio-files/icon_logos/colored_light/MonsterCat.png`,
    website: 'https://s3.amazonaws.com/dashradio-files/icon_logos/colored_light/MonsterCat.png',
    webcast: 'http://ice55.securenetsystems.net/DASH63',
    frequency: "N/A",
    country: "The United States Of America",
    tags: "Dance, Dash, Dashradio, Edm, Electronic, Electronica"
  },
  {
    name: 'Marijos radijas',
    logo: `https://i.imgur.com/0ZjgnW7.png`,
    website: 'http://www.marijosradijas.lt/',
    webcast: 'http://stream.marijosradijas.lt:8001/marijosradijas.mp3',
    frequency: "N/A",
    country: "Lithuania",
    tags: "Christian"
  },
//Russia
  {
    name: 'Radio Record',
    logo: `https://www.radiorecord.ru/local/templates/record/assets/build/favicon-set/apple-touch-icon.png`,
    website: 'https://www.radiorecord.ru/station/record',
    webcast: 'https://radiorecord.hostingradio.ru/rr_main96.aacp',
    frequency: "N/A",
    country: "The Russian Federation",
    tags: "N/A"
  },
  {
    name: 'Russian Mix',
    logo: `https://www.radiorecord.ru/local/templates/record/assets/build/favicon-set/apple-touch-icon.png`,
    website: 'https://www.radiorecord.ru/station/rus',
    webcast: 'https://radiorecord.hostingradio.ru/rus96.aacp',
    frequency: "N/A",
    country: "The Russian Federation",
    tags: "N/A"
  },
  {
    name: 'HypeFM',
    logo: `https://i.imgur.com/weUUCbf.png`,
    website: 'https://hypefm.ru',
    webcast: 'https://cdn.pifm.ru/mp3',
    frequency: "N/A",
    country: "The Russian Federation",
    tags: "N/A"
  },
  {
    name: 'RADIO R',
    logo: `https://radior.lt/wp-content/uploads/2022/05/rr_radio_spalvotas-300x51.png`,
    website: 'https://radior.lt/online/',
    webcast: 'https://stream1.rusradio.lt/rrb128.mp3',
    frequency: "N/A",
    country: "The Russian Federation",
    tags: "N/A"
  },
  {
    name: 'Пи FM',
    logo: `https://pifm.ru/img/ico/96х96.png`,
    website: 'https://pifm.ru',
    webcast: 'http://cdn.pifm.ru/mp3',
    frequency: "N/A",
    country: "The Russian Federation",
    tags: "Dance"
  },
];