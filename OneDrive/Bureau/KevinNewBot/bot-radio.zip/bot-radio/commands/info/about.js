const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('about')
		.setDescription('About command for the discord bot.')
		.setDescriptionLocalizations({
			'fr': 'Commande à propos du bot discord.',
			'ru': 'О команде для Discord бота.',
		})
		.setDMPermission(true),
	contextDescription: null,
	usage: 'about',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Broadcast} ${locale.about_msg}`);

			return await interaction.reply({ embeds: [embed]});
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};
