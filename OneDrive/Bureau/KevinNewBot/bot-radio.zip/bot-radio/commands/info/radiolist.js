const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('radiolist')
		.setDescription('Page of available radios')
		.setDescriptionLocalizations({
			'fr': 'Page des radios disponibles',
			'ru': 'Страница доступных радиостанций',
		})
		.setDMPermission(true),
	usage: 'radiolist',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const commands = await client.application.commands.fetch();
			const filtered = commands.filter(command => command.name.startsWith('radio-'));

			const informationEmbed = new EmbedBuilder()
				.setTitle('Radio Box')
				.setThumbnail(client.user.displayAvatarURL({ size: 2048 }))
				.setDescription(stripIndents`
				${client.emoji.Broadcast} ${locale.radiolist_l1}

				${client.emoji.Sciences} ${locale.radiolist_l2} **3** ${locale.radiolist_l3}
				
				${client.emoji.Tools} ${filtered.map(c => `</${c.name}:${c.id}>`).join(' ')}
				`)
				.setColor(client.color.yellow)
				.setFooter({
					text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
					iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
				});

			return await interaction.reply({ embeds: [informationEmbed] });
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};