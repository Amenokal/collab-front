const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('vote')
		.setDescription('Vote for the discord bot')
		.setDescriptionLocalizations({
			'fr': 'Votez pour le bot discord',
			'ru': 'Проголосовать за дискорд бота',
		})
		.setDMPermission(true),
	usage: 'vote',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Broadcast} ${locale.vote_msg}`);

			const buttonRow = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setLabel(`${locale.vote_button}`)
						.setURL(client.config.voteURL)
						.setStyle(ButtonStyle.Link),
						
						new ButtonBuilder()
						.setCustomId('success')
						.setLabel(`${locale.vote_thank_you_button}`)
						.setStyle(ButtonStyle.Success)
						.setDisabled(true)
				);
				

			return await interaction.reply({ embeds: [embed], components: [buttonRow] });
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};