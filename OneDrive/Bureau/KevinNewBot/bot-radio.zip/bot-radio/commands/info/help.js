const { EmbedBuilder, SlashCommandBuilder, Invite } = require('discord.js');
const { stripIndents } = require('common-tags');

const rn = require('../../assets/json/radioNumber.json');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Bot help page')
		.setDescriptionLocalizations({
			'fr': 'Page d\'aide du robot',
			'ru': 'Страница помощи робота',
		})
		.setDMPermission(true),
	usage: 'help',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const commands = await client.application.commands.fetch();
			const filtered = commands.filter(command => !command.name.startsWith('radio-'));
			const supportCMD = commands.filter(command => !command.name.startsWith('radio-') && !command.name.startsWith('botinfo') && !command.name.startsWith('help') && !command.name.startsWith('invite') && !command.name.startsWith('ping') && !command.name.startsWith('radiolist') && !command.name.startsWith('vote') && !command.name.startsWith('set-language') && !command.name.startsWith('about') && !command.name.startsWith('legal') && !command.name.startsWith('donate') && !command.name.startsWith('acknowledgements') && !command.name.startsWith('radioinfo-africa') && !command.name.startsWith('radioinfo-asia') && !command.name.startsWith('radioinfo-europe') && !command.name.startsWith('radioinfo-other') && !command.name.startsWith('radioinfo-russia'));
			const inviteCMD = commands.filter(command => !command.name.startsWith('radio-') && !command.name.startsWith('botinfo') && !command.name.startsWith('help') && !command.name.startsWith('support') && !command.name.startsWith('ping') && !command.name.startsWith('radiolist') && !command.name.startsWith('vote') && !command.name.startsWith('set-language') && !command.name.startsWith('about') && !command.name.startsWith('legal') && !command.name.startsWith('donate') && !command.name.startsWith('acknowledgements') && !command.name.startsWith('radioinfo-africa') && !command.name.startsWith('radioinfo-asia') && !command.name.startsWith('radioinfo-europe') && !command.name.startsWith('radioinfo-other') && !command.name.startsWith('radioinfo-russia'));

			const informationEmbed = new EmbedBuilder()
				.setTitle('Radio Box')
				.setThumbnail(client.user.displayAvatarURL({ size: 2048 }))
				.setDescription(stripIndents`
				${client.emoji.Broadcast} ${locale.help_l1} **${client.user.tag}** ${locale.help_l2}

				${client.emoji.Sciences} ${locale.help_l3} **${rn.radionumber} ${locale.help_l4}**.

				${client.emoji.Fusee} ${locale.help_l5} **${locale.help_l6}** ${locale.help_l7} ${supportCMD.map(c => `</${c.name}:${c.id}>`).join(' ')} ${locale.help_l8} ${inviteCMD.map(c => `</${c.name}:${c.id}>`).join(' ')}.

				${client.emoji.Tools} ${locale.help_l9} <#980777300725485578>.

				🏳 **${locale.help_l10}**: ${locale.flag} \`${locale.language}\`

				${client.emoji.Sciences} **${locale.help_l11}** :
				${filtered.map(c => `</${c.name}:${c.id}>`).join(' ')}
				`)
				.setColor(client.color.cyan)
				.setFooter({
					text: `${locale.footer_requestedby} ${interaction.user.username} | ©️ Radio Box`,
					iconURL: interaction.user.displayAvatarURL({ size: 2048 }),
				});

			return await interaction.reply({ embeds: [informationEmbed] });
		}
		catch (e) {
			return await interaction.deferReply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};