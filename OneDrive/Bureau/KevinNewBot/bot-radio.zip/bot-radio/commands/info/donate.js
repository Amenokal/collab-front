const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('donate')
		.setDescription('Donate for the discord bot.')
		.setDescriptionLocalizations({
			'fr': 'Faire un don pour le bot discord.',
			'ru': 'Пожертвовать на дискорд бота.',
		})
		.setDMPermission(true),
	contextDescription: null,
	usage: 'donate',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Sciences} ${locale.donate_msg}`);

			const buttonRow = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setLabel(`${locale.donate_button}`)
						.setURL(client.config.donateURL)
						.setStyle(ButtonStyle.Link),
				);

			return await interaction.reply({ embeds: [embed], components: [buttonRow] });
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};