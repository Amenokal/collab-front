const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('legal')
		.setDescription('The legal rights of the bot discord.')
		.setDescriptionLocalizations({
			'fr': 'Les droits légaux du bot discord.',
			'ru': 'Юридические права бота дискорда.',
		})
		.setDMPermission(true),
	contextDescription: null,
	usage: 'legal',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Sciences} ${locale.legal_msg}`);

			const buttonRow = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setLabel(`${locale.legal_button}`)
						.setURL(client.config.tosURL)
                        .setLabel(`${locale.legal_pp_button}`)
                        .setURL(client.config.ppURL)
						.setStyle(ButtonStyle.Link),
				);

			const buttonRow2 = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setLabel(`${locale.legal_button}`)
						.setURL(client.config.tosURL)
						.setStyle(ButtonStyle.Link),
				);

			return await interaction.reply({ embeds: [embed], components: [buttonRow, buttonRow2]});
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};