const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('selectradio')
		.setDescription('select radio')
		.setDMPermission(true),
	contextDescription: null,
	usage: 'about',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = new EmbedBuilder()
			.setTitle('Select Radio 📻')
			.setDescription(`${locale.select_radio}`)
			.setTimestamp();

			const selectRadioRow = new ActionRowBuilder()
			.addComponents(
				new StringSelectMenuBuilder()
					.setCustomId('select')
					.setPlaceholder(`📻 ${locale.radio_sm_placeholder}`)
					.addOptions([
						{
							label: 'Radio Africa',
							description: `${locale.radio_sm_description}: Africa radios.`,
							value: 'first_select_radio',
							emoji: '<:jacarandafm:1039696778557136906>',
						},
						{
							label: 'Radio Asia',
							description: `${locale.radio_sm_description}: Asia radios.`,
							value: 'second_select_radio',
							emoji: '<:Hot1027FM:1039698928989384756>',
						},
						{
							label: 'Radio Europe',
							description: `${locale.radio_sm_description}: Europe radios.`,
							value: 'third_select_radio',
							emoji: '<:Magic828:1039703846064242828>',
						},
						{
							label: 'Radio Other',
							description: `${locale.radio_sm_description}: Others radios.`,
							value: 'four_select_radio',
							emoji: '<:Magic828:1039703846064242828>',
						},
						{
							label: 'Radio Russia',
							description: `${locale.radio_sm_description}: Russian radios.`,
							value: 'five_select_radio',
							emoji: '<:Magic828:1039703846064242828>',
						}
					]),
			);


			return interaction.reply({ embeds: [embed], components: [selectRadioRow] });
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};
