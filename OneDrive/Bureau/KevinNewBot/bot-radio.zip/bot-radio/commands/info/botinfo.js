const { EmbedBuilder, time, version, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');
const system = require('systeminformation');
const os = require('os');
const moment = require('moment');
require('moment-duration-format');

const package = require('../../package.json');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('botinfo')
		.setDescription('See information of the bot')
		.setDescriptionLocalizations({
			'fr': 'Voir les informations du robot',
			'ru': 'Посмотреть информацию о роботе',
		})
		.setDMPermission(true),
	usage: 'botinfo',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			await interaction.deferReply();

			moment.locale('fr-fr');

			const cpu = await system.cpu();
			const duration = moment.duration(client.uptime).format('D [days], H [hours], m [minutes], s [seconds]');

			const embed = new EmbedBuilder()
				.setThumbnail(client.user.displayAvatarURL({ size: 2048 }))
				.setColor(client.color.blue)
				.addFields(
					{
						name: `${locale.botinfo_myinformation}`,
						value: stripIndents`
                        > <a:developer_bot:1008000752381349900>・**${locale.botinfo_myname}**: \`${client.user.username}\`
                        > <a:developer_bot:1008000752381349900>・**${locale.botinfo_mydiscriminator}**: \`${client.user.discriminator}\`
						> <:2899info:993208530293235843>・**${locale.botinfo_id}**: \`813437884283486280\`
						> <:verifiedserverbadge:1021806820987240528>・**${locale.botinfo_ServersCount}** : \`${client.guilds.cache.size} ${locale.botinfo_Servers}\`
						> <:verifiedserverbadge:1021806820987240528>・**${locale.botinfo_UserCount}** : \`${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)} ${locale.botinfo_User}\`
                        > ⚙️・**${locale.botinfo_version}**: \`v${package.version}\`
						> <:discordslashcommands:1022547711830007828> ・**${locale.botinfo_CommandCount}** : \`14\`
                        > <:wumpus_crown:1007995150632501339>・**${locale.botinfo_mycreator}**: \`${package.author}\`
                        > <:nodejs:1007994025447526430> ・**Node.JS**: \`${process.version}\`
                        > <:library:1007995404949921814>・**${locale.botinfo_library}**: Discord.JS \`v${version}\`
                        > <:clocks:993222986427539526>:・**${locale.botinfo_timeonline}**: \`${duration}\`
                        > <:clocks:993222986427539526>:・**${locale.botinfo_createdat}**: ${time(Math.trunc(client.user.createdAt / 1000), 'D')}
                        `,
					},
					{
						name: `${locale.botinfo_hostinformation}`,
						value: stripIndents`
                        > **${locale.botinfo_processor}**: \`${cpu.manufacturer} ${cpu.brand} ${cpu.family}°\`
                        > **${locale.botinfo_hosting}**: \`https://cp.ihcb-group.com/aff.php?aff=4\`
                        > **${locale.botinfo_os}**: \`${os.platform()}\`
                        `,
					},
				);

			return await interaction.editReply({ embeds: [embed] });
		}
		catch (e) {
			return await interaction.editReply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};