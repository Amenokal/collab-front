const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('invite')
		.setDescription('Add the bot')
		.setDescriptionLocalizations({
			'fr': 'Ajouter le robot.',
			'ru': 'Добавить бота.',
		})
		.setDMPermission(true),
	contextDescription: null,
	usage: 'invite',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `${client.emoji.Sciences} ${locale.invite_msg}`);

			const buttonRow = new ActionRowBuilder()
				.addComponents(
					new ButtonBuilder()
						.setLabel(`${locale.invite_button}`)
						.setURL(client.config.inviteURL)
						.setStyle(ButtonStyle.Link),
				);

			return await interaction.reply({ embeds: [embed], components: [buttonRow] });
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};