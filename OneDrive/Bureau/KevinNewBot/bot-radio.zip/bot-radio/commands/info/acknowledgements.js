const { ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('acknowledgements')
		.setDescription('Acknowledgements command.')
		.setDescriptionLocalizations({
			'fr': 'Commande de remerciement.',
			'ru': 'Спасибо за заказ.',
		})
		.setDMPermission(true),
	contextDescription: null,
	usage: 'acknowledgements',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const embed = client.util.CattoEmbed(client, interaction.user, `<:wumpus_crown:1007995150632501339> ${locale.acknowledgements}\n
			${locale.acknowledgements_list_corrector}\n - Élisabeth de Sainte-Grâce#2853 [${locale.acknowledgements_list_corrector_file_corrector}]\n
			${locale.acknowledgements_list_translator}\n - UltraLion#0404 [${locale.acknowledgements_list_translator_language_french} & ${locale.acknowledgements_list_translator_language_english}]\n
			- Lёша#8800 [${locale.acknowledgements_list_translator_language_russia}]\n
			${locale.acknowledgements_list_development_assistance}\n - Eshi#1424\n
			${locale.acknowledgements_list_logo_design}\n - Iky#0001\n
			${locale.acknowledgements_list_hosting_company}\n - IHCB GROUP [${locale.acknowledgements_list_hosting_company_vps}]\n - NiHost [${locale.acknowledgements_list_hosting_company_website}]\n
			`); 

			return await interaction.reply({ embeds: [embed]});
		}
		catch (e) {
			return await interaction.reply({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};
