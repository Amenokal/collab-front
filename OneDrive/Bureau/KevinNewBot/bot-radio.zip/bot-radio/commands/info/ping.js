const { SlashCommandBuilder } = require('discord.js');
const { stripIndents } = require('common-tags');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('The ping (latency) of the bot.')
		.setDescriptionLocalizations({
			'fr': 'Le ping (latence) du bot.',
		})
		.setDMPermission(true),
	usage: 'ping',
	cooldown: 5,
	category: 'Info',
	run: async (client, interaction, locale) => {
		try {
			const now = Date.now();
			await interaction.deferReply();

			return await interaction.editReply({ content: stripIndents`
            **<:clocks:993222986427539526> ${locale.ping_roundtrip}:** \`${Math.round(Date.now() - now)}\` ${locale.ping_ms}
            **<:wumpus_crown:1007995150632501339> ${locale.ping_api}:** \`${Math.round(client.ws.ping)}\` ${locale.ping_ms}
            ` });
		}
		catch (e) {
			return await interaction.followUp({ content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};