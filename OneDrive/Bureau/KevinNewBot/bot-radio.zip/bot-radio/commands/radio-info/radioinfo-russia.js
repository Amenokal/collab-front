const { SlashCommandBuilder } = require("discord.js");

const { stripIndents } = require("common-tags");
const radioInfo = require("../../util/radioInfo");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("radioinfo-russia")
    .setDescription("Get info about the radios")
    .setDescriptionLocalizations({
      fr: "Obtenir des informations sur les radios",
      ru: "Получить информацию о радио",
    })
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("Select the radio")
        .setDescriptionLocalizations({
          fr: "Sélectionnez l'autoradio",
          ru: "Выберите радио",
        })
        .setRequired(true)
        .addChoices(
          { name: "Radio Record", value: "Radio Record" },
          { name: "Russian Mix", value: "Russian Mix" },
          { name: "HypeFM", value: "HypeFM" },
          { name: "RADIO R", value: "RADIO R" },
          { name : "Пи FM", value: "Пи FM" }
        )
    ),
  usage: "radioinfo-russia",
  cooldown: 5,
  category: "Radio",
  run: async (client, interaction, locale) => {
    try {
      await radioInfo(interaction);
    } catch (e) {
      return await interaction.followUp({
        content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            `,
      });
    }
  },
};
