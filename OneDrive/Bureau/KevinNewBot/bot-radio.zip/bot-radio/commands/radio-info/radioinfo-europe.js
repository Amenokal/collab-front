const { SlashCommandBuilder } = require("discord.js");

const { stripIndents } = require("common-tags");
const radioInfo = require("../../util/radioInfo");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("radioinfo-europe")
    .setDescription("Get info about the radios")
    .setDescriptionLocalizations({
      fr: "Obtenir des informations sur les radios",
      ru: "Получить информацию о радио",
    })
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("Select the radio")
        .setDescriptionLocalizations({
          fr: "Sélectionnez l'autoradio",
          ru: "Выберите радио",
        })
        .setRequired(true)
        .addChoices(
          { name: "Nrj", 
            value: "Nrj" 
          },
          { name: "Skyrock", 
            value: "Skyrock" 
          },
          { name: "RFM", 
            value: "RFM" 
          },
          { name: "Rap FR Gold", 
            value: "Rap FR Gold" 
          },
          { name: "Classique", 
            value: "Classique" 
          },
          { name: "Mouv'", 
            value: "Mouv'" },
          { name: "NOSTALGIE", 
            value: "NOSTALGIE" 
          },
          { name: "Chérie FM", 
            value: "Chérie FM" 
          },
          { name: "FUNRADIO", 
            value: "FUNRADIO" 
          },
          { name: "MeGaMoV", 
            value: "MeGaMoV" 
          },
          { name: "NRJ METAL", 
            value: "NRJ METAL" 
          },
          { name: "FranceInfo", 
            value: "FranceInfo" 
          },
          {
            name: "France Musique La Baroque",
            value: "France Musique La Baroque",
          },
          { name: "France Flip", 
            value: "France Flip" 
          },
          { name: "EuroDance 90", 
            value: "EuroDance 90" 
          }
        )
    ),
  usage: "radioinfo-europe",
  cooldown: 5,
  category: "Radio",
  run: async (client, interaction, locale) => {
    try {
      await radioInfo(interaction);
    } catch (e) {
      return await interaction.followUp({
        content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            `,
      });
    }
  },
};
