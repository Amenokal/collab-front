const { SlashCommandBuilder } = require("discord.js");

const { stripIndents } = require("common-tags");
const radioInfo = require("../../util/radioInfo");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("radioinfo-other")
    .setDescription("Get info about the radios")
    .setDescriptionLocalizations({
      fr: "Obtenir des informations sur les radios",
      ru: "Получить информацию о радио",
    })
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("Select the radio")
        .setDescriptionLocalizations({
          fr: "Sélectionnez l'autoradio",
          ru: "Выберите радио",
        })
        .setRequired(true)
        .addChoices(
          { name: "Jazz on Radio", value: "Jazz on Radio" },
          { name: "Lofi Radio", value: "Lofi Radio" },
          { name: "Nightwave Plaza", value: "Nightwave Plaza" },
          { name: "Last.fm EuroBeat", value: "Last.fm EuroBeat" },
          { name: "TechnoBase.FM", value: "TechnoBase.FM" },
          { name: "Proton Radio", value: "Proton Radio" },
          { name: "AnimeRadio.de", value: "AnimeRadio.de" },
          { name: "Happy Christmas Radio", value: "Happy Christmas Radio" },
          { name: "Radio Box", value: "Radio Box" },
          { name: "80s Hits - Open FM", value: "80s Hits - Open FM" },
          {
            name: "Monstercat - Electronic Music",
            value: "Monstercat - Electronic Music",
          },
          { name: "Marijos radijas", value: "Marijos radijas" }
        )
    ),
  usage: "radioinfo-other",
  cooldown: 5,
  category: "Radio",
  run: async (client, interaction, locale) => {
    try {
      await radioInfo(interaction);
    } catch (e) {
      return await interaction.followUp({
        content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            `,
      });
    }
  },
};
