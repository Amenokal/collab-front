const { SlashCommandBuilder } = require("discord.js");
const { stripIndents } = require("common-tags");
const radioInfo = require("../../util/radioInfo");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("radioinfo-africa")
    .setDescription("Get info about the radios")
    .setDescriptionLocalizations({
      fr: "Obtenir des informations sur les radios",
      ru: "Получить информацию о радио",
    })
    .setDMPermission(false)
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("Select the radio")
        .setDescriptionLocalizations({
          fr: "Sélectionnez l'autoradio",
          ru: "Выберите радио",
        })
        .setRequired(true)
        .addChoices(
          { name: "Jacaranda FM", value: "Jacaranda FM" },
          { name: "Hot 102.7 FM", value: "Hot 102.7 FM" },
          { name: "Magic 828", value: "Magic 828" }
        )
    ),
  usage: "radioinfo-africa",
  cooldown: 5,
  category: "Radio",
  run: async (client, interaction, locale) => {
    try {
      await radioInfo(interaction);
    } catch (e) {
      return await interaction.followUp({
        content: stripIndents`
            **${locale.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            `,
      });
    }
  },
};
