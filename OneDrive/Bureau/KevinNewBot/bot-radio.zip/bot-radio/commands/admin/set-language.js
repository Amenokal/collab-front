const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { stripIndents } = require('common-tags');
const db = require('quick.db');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('set-language')
		.setDescription('Set the language of the bot for the current server.')
		.setDescriptionLocalizations({
			'fr': 'Définir la langue du bot pour le serveur actuel',
			'ru': 'Установить язык бота для текущего сервера',
		})
		.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
		.setDMPermission(false)
		.addStringOption(option =>
			option
				.setName('type')
				.setDescription('The language to set.')
				.setDescriptionLocalizations({
					'fr': 'La langue à définir.',
					'ru': 'Язык для установки.',
				})
				.setRequired(true)
				.addChoices(
					{
						name: 'English',
						value: 'en',
					},
					{
						name: 'French (Français)',
						value: 'fr',
					},
					{
						name: 'Russian',
						value: 'ru',
					},
				),
		),
	usage: 'set-language',
	cooldown: 10,
	category: 'Info',
	run: async (client, interaction, l) => {

		try {
			await interaction.deferReply();

			const type = interaction.options.getString('type');

			const locale = await db.fetch(`locale_${interaction.guild.id}`);
			if (locale === type) return await interaction.editReply({ content: stripIndents `${client.emoji.Warn} ${l.set_language_locale} \`${type}\`.` });

			await db.set(`locale_${interaction.guild.id}`, type);

			return await interaction.editReply({ content: stripIndents`✅ ${l.valid_set_language_locale} \`${type}\`.` });
		}

		catch (e) {
			return await interaction.followUp({ content: stripIndents`
            **${l.cmd_error} \`${interaction.commandName}\`**
            
            \`\`\`
            ${e.message}
            \`\`\`
            ` });
		}
	},
};