const client = require("..");
const { EmbedBuilder, Collection, PermissionsBitField } = require("discord.js");
const ms = require("ms");
const prefix = client.prefix;
const cooldown = new Collection();
const global = require('../config');

client.on("messageCreate", async (message) => {
  try {
    if (message.author.bot) return;
    const badWords = ["idiot", "stupid", "shut up", "fdp"];
    const badWordsRegex = new RegExp(`\\b(${badWords.join("|")})\\b`, "gi");
    if (message.content.match(badWordsRegex)) {
      message.channel.messages
        .fetch(message.id)
        .then((msg) => {
          msg.delete();
        })
        .catch(() => {
          // Do nothing if the message doesn't exist
        });
      const channel = message.guild.channels.cache.find((ch) => ch.id === global.channelLogs);
      message.channel.send(
        `<@${message.author.id}>, ton message a été supprimé car tu ne peux pas envoyer des insultes !`
      );
      message.author.send(
        `<@${message.author.id}>, ton message a été supprimé car tu ne peux pas envoyer des insultes !`
      );
      const embed = new EmbedBuilder()
        .setTitle("INFOS!")
        .setDescription(
          `Le message de <@${message.author.id}>: **${message.content}** a été supprimé !`
        )
        .setColor(0xff1000)
        .setTimestamp();
      channel.send({ embeds: [embed] });

     // if (!(await db.get(`${message.author.id}_warn`))) db.set(`${message.author.id}`, 0);

      //db.add(`${message.author.id}_warn`, 1);
        let muteRole = message.guild.roles.cache.find((r) => r.name === "Muted");
        let member = message.guild.members.cache.get(message.author.id);
        await member.roles.add(muteRole).then(() => {
          const embedBan = new EmbedBuilder()
            .setTitle("Un membre a été mute !")
            .setDescription(
              `<@${member.user.id}> tu as été mute du serveur car tu as depassé la limite de 3 avertissements !`
            )
            .setColor(0xff0000)
            .setTimestamp();

        // db.set(`${message.author.id}_warn`, 0);
        return message.channel.send({ embeds: [embedBan] });
        });
    }
  } catch (err) {
    console.log(err);
  }
});
