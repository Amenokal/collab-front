const { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder } = require('discord.js');
const client = new Client({
	intents: [
		GatewayIntentBits.Guilds, 
		GatewayIntentBits.GuildMessages, 
		GatewayIntentBits.GuildPresences, 
		GatewayIntentBits.GuildMessageReactions, 
		GatewayIntentBits.DirectMessages,
		GatewayIntentBits.GuildMembers,
		GatewayIntentBits.MessageContent
	], 
	partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction] 
});

const {token, channelInvite} = require('./config.json')

const config = require('./config.json');
require('dotenv').config()

client.commands = new Collection()
client.aliases = new Collection()
client.slashCommands = new Collection();
client.prefix = config.prefix

module.exports = client;

[ 'slashCommand', 'events'].forEach((handler) => {
  require(`./handlers/${handler}`)(client)
});

const InvitesTracker = require('@androz2091/discord-invites-tracker');
const tracker = InvitesTracker.init(client, {
    fetchGuilds: true,
    fetchVanity: true,
    fetchAuditLogs: true
});


tracker.on('guildMemberAdd', async(member, type, invite) => {
	const inviteChannel = member.guild.channels.cache.find((ch) => ch.id === channelInvite);
	const sendEmbed = (description) => {
			const embedSend = new EmbedBuilder()
			.setTitle('Invite Tracker')
			.setDescription(description)
			.setColor(0x5865f2);
			inviteChannel.send({embeds: [embedSend]});
	}

    if(type === 'normal') {
		const embedSend = new EmbedBuilder()
		.setTitle('Invite Tracker')
		.setDescription(`Bienvenue ${member}! Tu as été invité par ${invite.inviter.username}!`)
		.setColor(0x9865f2)

		return inviteChannel.send({embeds: [embedSend]});
    }
    else if(type === 'vanity') {
		sendEmbed(`Bienvenue ${member}! Tu as rejoins en utilisant une invitation customisé !!`)
    }
    else if(type === 'permissions') {
        sendEmbed(`Bienvenue ${member}! Je ne peux pas te dire comment tu as rejoins le serveur, car je n'ai pas la permission 'Manage Server'`);
    }
    else if(type === 'unknown') {
        sendEmbed(`Bienvenue ${member}! Je ne peux pas te dire comment tu as rejoins le serveur...`);
    }
});

client.login(token);