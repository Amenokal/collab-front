const {
  ApplicationCommandOptionType,
  PermissionsBitField,
} = require("discord.js");
const { guildID } = require("../../config.json");

module.exports = {
  name: "sendmsgall",
  usage: "/sendmsgall <msg>",
  options: [
    {
      name: "msg",
      description: "Le msg a envoyer à tous",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
  ],
  category: "Bot",
  description: "Envoyer un message à tous les membres du serveurs",
  ownerOnly: false,
  run: async (client, interaction) => {
    try {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
        return interaction.reply(`❌ | Tu n'as pas la permission d'envoyer un message à tous les membres du serveurs !`)
    }
      const guild = client.guilds.cache.get(guildID);
      const msg = interaction.options.getString('msg')

      guild.members.cache.forEach((member) => {
        member.send(msg)
        .then((res)=> {
            interaction.channel.send(`Message envoyé à <@${member.user.id}>`);
        })
        .catch((err)=> {
            interaction.channel.send(`Impossible d'envoyer un msg à <@${member.user.id}> car il n'accepte pas les msg privés !`);
        });
      });
    } catch (err) {
      return interaction.channel.send(
        `❌ | A error occured **sendmsgall.js**: ${err}`
      );
    }
  },
};
