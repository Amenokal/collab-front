const { EmbedBuilder, ApplicationCommandOptionType,ApplicationCommandType , PermissionsBitField } = require("discord.js");
const global = require('../../config');
module.exports = {
    name: "kick",
    usage: '/kick <command>',
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'user',
            description: 'Le membre que tu souhaites kick',
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
          name: 'reason',
          description: 'Le raison du kick',
          type: ApplicationCommandOptionType.String,
          required: true
      },
      {
        name: "channel",
        description: "Channel où envoyer le resultat du kick",
        type: ApplicationCommandOptionType.Channel,
        required: true,
      },
    ],
    category: "Bot",
    description: "🦶🏽 Kick un membre du serveur !",
    ownerOnly: false,
    run: async (client, interaction) => {
      try {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
          return interaction.reply(`❌ | Tu n'as pas la permission de kick un membre !`)
        }

        const user = interaction.options.getUser('user');
        let member = interaction.guild.members.cache.get(user.id);
        const reason = interaction.options.getString('reason');
        const channel = interaction.options.getChannel("channel");

        await member.kick()
        .then(()=> {
          const embedBan = new EmbedBuilder()
          .setTitle('Un membre a été kick !')
          .setDescription(`${member.user.username} a été kick du serveur !\nRaison: ${reason}`)
          .setColor(0xff0000);

          
          const channelLogs = interaction.guild.channels.cache.find((ch) => ch.id === global.channelLogs);
          channelLogs.send({ embeds: [embedBan] });

          return channel.send({ embeds: [embedBan] });
        })      
      }
      catch(err) {
          return interaction.channel.send(`❌ | A error occured **kick.js**: ${err}`);
      }
    },
};