
const {
    EmbedBuilder,
    ApplicationCommandOptionType,
    ApplicationCommandType,
    PermissionsBitField,
  } = require("discord.js");
  
  module.exports = {
    name: "say",
    usage: "/say <contenu> <channel>",
    type: ApplicationCommandType.ChatInput,
    options: [
      {
        name: "contenu",
        description: "Le contenu à envoyer",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
      {
        name: "channel",
        description: "Le channel où envoyer",
        type: ApplicationCommandOptionType.Channel,
        required: false,
      },
    ],
    category: "Bot",
    description: "🚫 Bannir un membre du serveur !",
    ownerOnly: false,
    run: async (client, interaction) => {
      try {
        if (
          !interaction.member.permissions.has(
            PermissionsBitField.Flags.KickMembers
          )
        ) {
          return interaction.reply(
            `❌ | Tu n'as pas la permission de ban un membre !`
          );
        }
  
        const content = interaction.options.getString("contenu");
        const channel = interaction.options.getChannel("channel");
        if(channel) return channel.send(content)
        .then(()=> {
            interaction.channel.send(`Message envoyé avec succès dans le salon <#${channel.id}>`);
        })
        return interaction.channel.send(content);
        
      } catch (err) {
        return interaction.channel.send(
          `❌ | A error occured **say.js**: ${err}`
        );
      }
    },
  };
  